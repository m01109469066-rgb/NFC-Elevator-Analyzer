package com.example.nfcelevator

import android.app.Activity
import android.app.PendingIntent
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.animation.Animation
import android.view.animation.ScaleAnimation
import android.animation.ValueAnimator
import android.view.animation.LinearInterpolator
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), NfcAdapter.ReaderCallback {
    private val gold = 0xFFD6AD55.toInt()
    private val bg = 0xFF090909.toInt()
    private val panel = 0xFF171717.toInt()
    private val white = 0xFFF4F0E8.toInt()
    private val muted = 0xFFAAA39A.toInt()
    private val prefs by lazy { getSharedPreferences("local_vault", MODE_PRIVATE) }
    private var adapter: NfcAdapter? = null
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var pulse: PulseView
    private var scanning = false
    private var lastResult = "لا توجد عملية فحص بعد"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        adapter = NfcAdapter.getDefaultAdapter(this)
        buildShell()
        showHome()
    }

    private fun buildShell() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 24, 22, 14) }
        header.addView(label("NFC ELEVATOR ANALYZER", 19f, gold, true))
        header.addView(label("الإصدار 2.0  •  تخزين محلي دون إنترنت", 12f, muted))
        root.addView(header)
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 8, 18, 20) }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply { setPadding(8, 8, 8, 12); gravity = Gravity.CENTER; setBackgroundColor(0xFF111111.toInt()) }
        listOf("الرئيسية", "الفحص", "السجل", "الأدوات").forEachIndexed { i, t ->
            val b = Button(this).apply { text = t; textSize = 11f; setTextColor(gold); setBackgroundColor(0xFF111111.toInt()); setOnClickListener { when(i) { 0 -> showHome(); 1 -> showScanner(); 2 -> showHistory(); else -> showTools() } } }
            nav.addView(b, LinearLayout.LayoutParams(0, 48, 1f))
        }
        root.addView(nav)
        setContentView(root)
        content.tag = "main_content"
    }

    private fun content(): LinearLayout = (root.getChildAt(1) as ScrollView).getChildAt(0) as LinearLayout
    private fun clear() = content().removeAllViews()
    private fun label(s: String, size: Float = 14f, color: Int = white, bold: Boolean = false): TextView = TextView(this).apply { text = s; textSize = size; setTextColor(color); if (bold) setTypeface(null, 1); setPadding(0, 5, 0, 5) }
    private fun card(title: String, desc: String, action: (() -> Unit)? = null) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 13, 16, 13); setBackgroundColor(panel) }
        box.addView(label(title, 16f, gold, true)); box.addView(label(desc, 13f, muted))
        if (action != null) box.setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 10; content().addView(box, lp)
    }
    private fun button(text: String, action: () -> Unit) {
        val b = Button(this).apply { this.text = text; setTextColor(bg); setBackgroundColor(gold); textSize = 13f; setOnClickListener { action() } }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 9; content().addView(b, lp)
    }
    private fun title(s: String) { content().addView(label(s, 21f, gold, true)) }
    private fun nfcState(): String = when { adapter == null -> "هذا الهاتف لا يعلن عن دعم NFC"; adapter?.isEnabled == true -> "NFC مفعّل وجاهز للفحص"; else -> "NFC موجود لكنه متوقف" }

    private fun showHome() {
        stopReader(); clear(); title("مرحبًا بك")
        content().addView(label("أدوات فحص NFC وقراءة البيانات العامة وإدارة نتائجك محليًا.", 14f, muted))
        card("حالة الهاتف", nfcState())
        card("خصوصيتك أولًا", "الفحوصات والإعدادات محفوظة داخل مساحة التطبيق على الهاتف. لا يوجد تسجيل دخول أو اتصال بسيرفر.")
        button("فحص NFC الآن") { showScanner() }
        button("شرح مكان حساس NFC") { showGuide() }
        button("سجل الفحوصات") { showHistory() }
        button("الأدوات والتقارير") { showTools() }
    }

    private fun showScanner() {
        clear(); title("فحص NFC")
        status = label(nfcState(), 14f, white); content().addView(status)
        pulse = PulseView(this); content().addView(pulse, LinearLayout.LayoutParams(-1, 210))
        button("تفعيل NFC من إعدادات النظام") {
            if (adapter == null) toast("هذا الهاتف لا يدعم NFC حسب النظام") else startActivity(Intent(Settings.ACTION_NFC_SETTINGS))
        }
        button("بدء الاستماع للشريحة") {
            if (adapter == null) toast("لا يوجد NFC على هذا الهاتف")
            else if (adapter?.isEnabled != true) { toast("فعّل NFC من إعدادات النظام أولًا"); startActivity(Intent(Settings.ACTION_NFC_SETTINGS)) }
            else { startReader(); status.text = "قرّب الشريحة من ظهر الهاتف"; pulse.startPulse() }
        }
        button("إيقاف الفحص") { stopReader(); status.text = "تم إيقاف الاستماع"; pulse.stopPulse() }
        card("آخر نتيجة", lastResult)
        card("معلومة", "الهاتف لا يقرأ كل أنواع RFID. وقد لا يستطيع تحديد نوع قارئ المصعد أو توافقه، كما أن UID ليس مفتاح دخول ولا يثبت التوافق.")
    }

    private fun startReader() {
        val a = adapter ?: return
        val flags = NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B or NfcAdapter.FLAG_READER_NFC_F or NfcAdapter.FLAG_READER_NFC_V or NfcAdapter.FLAG_READER_NO_PLATFORM_SOUNDS
        a.enableReaderMode(this, this, flags, null); scanning = true
    }
    private fun stopReader() { if (scanning) { adapter?.disableReaderMode(this); scanning = false } }

    override fun onTagDiscovered(tag: Tag) {
        val techs = tag.techList.map { it.substringAfterLast('.') }.distinct()
        var ndefInfo = "لا توجد بيانات NDEF قابلة للقراءة"
        try {
            val ndef = Ndef.get(tag)
            if (ndef != null) {
                ndef.connect()
                ndefInfo = "NDEF: ${if (ndef.isWritable) "قابل للكتابة" else "للقراءة فقط"} • السعة ${ndef.maxSize} بايت"
                ndef.close()
            }
        } catch (_: Exception) { ndefInfo = "تعذر قراءة معلومات NDEF" }
        val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        val result = JSONObject().put("time", time).put("technologies", JSONArray(techs)).put("ndef", ndefInfo)
        synchronized(this) {
            val arr = JSONArray(prefs.getString("history", "[]"))
            arr.put(0, result); while (arr.length() > 100) arr.remove(arr.length() - 1)
            prefs.edit().putString("history", arr.toString()).apply()
        }
        lastResult = "${techs.joinToString(", ")}\n$ndefInfo\n$time"
        runOnUiThread { if (::status.isInitialized) status.text = "تم اكتشاف شريحة وحفظ النتيجة محليًا"; if (::pulse.isInitialized) pulse.stopPulse(); toast("تم حفظ نتيجة الفحص") }
    }

    private fun showHistory() {
        stopReader(); clear(); title("سجل الفحوصات")
        val arr = JSONArray(prefs.getString("history", "[]"))
        if (arr.length() == 0) content().addView(label("لا توجد فحوصات محفوظة حتى الآن.", 14f, muted))
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i); card("فحص ${i + 1} • ${o.optString("time")}", "التقنيات: ${o.optJSONArray("technologies")?.join(", ")}\n${o.optString("ndef")}")
        }
        button("مسح سجل الفحوصات") { prefs.edit().putString("history", "[]").apply(); showHistory() }
        button("تصدير نسخة احتياطية JSON") { exportBackup() }
    }

    private fun showGuide() {
        clear(); title("أين يوجد حساس NFC؟")
        content().addView(label("في كثير من الهواتف يكون الحساس قرب الجزء العلوي من الظهر، لكن موضعه يختلف حسب الطراز.", 14f, muted))
        val v = PulseView(this); content().addView(v, LinearLayout.LayoutParams(-1, 250)); v.startPulse()
        card("طريقة الاستخدام", "قرّب البطاقة ببطء من ظهر الهاتف وحرّكها قليلًا حتى يكتشفها. لا تعتمد على الرسم لتحديد مكان الحساس بدقة؛ راجع دليل هاتفك.")
        button("اذهب إلى الفحص") { showScanner() }
    }

    private fun showTools() {
        stopReader(); clear(); title("الأدوات")
        card("مقارنة الفحوصات", "عرض عدد الفحوصات والتقنيات التي ظهرت في آخر عمليتين.")
        button("مقارنة آخر فحصين") { compare() }
        button("إنشاء تقرير PDF") { createPdf() }
        button("نسخ احتياطي محلي") { exportBackup() }
        button("استعادة نسخة JSON") { restoreBackup() }
        button("الإعدادات والخصوصية") { showSettings() }
        button("شرح حساس NFC") { showGuide() }
    }

    private fun compare() {
        clear(); title("مقارنة الفحوصات")
        val a = JSONArray(prefs.getString("history", "[]"))
        if (a.length() < 2) { content().addView(label("تحتاج إلى فحص شريحتين على الأقل للمقارنة.", 14f, muted)); return }
        for (i in 0..1) { val o = a.getJSONObject(i); card("الفحص ${i + 1} • ${o.optString("time")}", "التقنيات: ${o.optJSONArray("technologies")?.join(", ")}\n${o.optString("ndef")}") }
    }

    private fun createPdf() {
        val arr = JSONArray(prefs.getString("history", "[]"))
        val doc = PdfDocument(); val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val p = Paint().apply { color = android.graphics.Color.BLACK; textSize = 18f }
        page.canvas.drawText("NFC ELEVATOR ANALYZER - Report", 35f, 45f, p); p.textSize = 11f
        page.canvas.drawText("Local scan history: ${arr.length()} records", 35f, 72f, p)
        var y = 105f
        for (i in 0 until minOf(arr.length(), 25)) {
            val o = arr.getJSONObject(i); page.canvas.drawText("${i + 1}. ${o.optString("time")} | ${o.optString("ndef")}", 35f, y, p); y += 25f
            if (y > 800f) break
        }
        doc.finishPage(page)
        val dir = File(filesDir, "reports").apply { mkdirs() }; val file = File(dir, "NFC_Report_${System.currentTimeMillis()}.pdf")
        try { file.outputStream().use { doc.writeTo(it) }; toast("تم حفظ التقرير داخل ملفات التطبيق: reports") } catch (e: Exception) { toast("تعذر إنشاء التقرير: ${e.message}") } finally { doc.close() }
    }

    private fun exportBackup() {
        val file = File(filesDir, "NFC_Backup.json")
        file.writeText(JSONObject().put("version", 2).put("history", JSONArray(prefs.getString("history", "[]"))).toString(2))
        toast("تم حفظ النسخة الاحتياطية داخل ملفات التطبيق")
    }
    private fun restoreBackup() {
        val file = File(filesDir, "NFC_Backup.json")
        if (!file.exists()) { toast("لا توجد نسخة احتياطية داخل مجلد التطبيق بعد"); return }
        try { val obj = JSONObject(file.readText()); prefs.edit().putString("history", obj.optJSONArray("history")?.toString() ?: "[]").apply(); toast("تمت استعادة النسخة الاحتياطية") }
        catch (_: Exception) { toast("ملف النسخة الاحتياطية غير صالح") }
    }
    private fun showSettings() {
        clear(); title("الإعدادات والخصوصية")
        card("التخزين", "كل البيانات داخل مساحة التطبيق الخاصة. لا يحتاج الفحص أو السجل أو التقارير إلى الإنترنت.")
        card("النسخ الاحتياطي", "يمكنك إنشاء نسخة JSON محلية. حذف التطبيق أو مسح بياناته قد يحذف الملفات؛ احتفظ بنسخة خارجية عند الحاجة.")
        card("حدود الفحص", "لا يستنسخ التطبيق البطاقات، ولا يستخرج مفاتيح حماية، ولا يفتح المصاعد. توافق أنظمة الدخول يتطلب تأكيدًا من الإدارة أو الشركة المختصة.")
        button("العودة للرئيسية") { showHome() }
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    override fun onPause() { stopReader(); super.onPause() }

    private class PulseView(context: android.content.Context) : View(context) {
        private val paint = Paint(3).apply { color = 0xFFD6AD55.toInt(); style = Paint.Style.STROKE; strokeWidth = 3f }
        private var active = false; private var phase = 0f
        private var animator: ValueAnimator? = null
        fun startPulse() {
            active = true
            animator?.cancel()
            animator = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 1500; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
                addUpdateListener { phase = it.animatedValue as Float; invalidate() }; start()
            }
        }
        fun stopPulse() { active = false; animator?.cancel(); animator = null; invalidate() }
        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val cx = width / 2f; val cy = height / 2f
            paint.alpha = 255
            c.drawRoundRect(RectF(cx-48, cy-82, cx+48, cy+82), 22f, 22f, paint)
            paint.alpha = 180; c.drawCircle(cx, cy+42, 11f, paint)
            if (active) {
                paint.alpha = 150
                c.drawCircle(cx, cy+42, 25f + phase*42f, paint)
                c.drawCircle(cx, cy+42, 25f + ((phase+0.5f)%1f)*42f, paint)
                // Animated hand indicator moves from the phone's top edge toward its rear sensor area.
                paint.alpha = 255; paint.strokeWidth = 7f; paint.strokeCap = Paint.Cap.ROUND
                val handY = cy - 118f + phase * 92f
                c.drawLine(cx+88f, handY, cx+48f, handY+28f, paint)
                c.drawCircle(cx+88f, handY, 9f, paint)
            } else { paint.alpha = 130; c.drawCircle(cx, cy+42, 25f, paint) }
        }
    }
}
