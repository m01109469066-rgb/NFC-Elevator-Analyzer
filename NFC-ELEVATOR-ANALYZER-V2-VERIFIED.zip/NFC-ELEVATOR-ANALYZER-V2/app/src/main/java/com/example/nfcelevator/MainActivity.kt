package com.example.nfcelevator

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), NfcAdapter.ReaderCallback {

    private var nfcAdapter: NfcAdapter? = null
    private var readerActive = false
    private val prefs by lazy { getSharedPreferences("local_nfc_data", MODE_PRIVATE) }

    private val background = Color.rgb(15, 15, 19)
    private val panel = Color.rgb(29, 29, 35)
    private val gold = Color.rgb(218, 176, 91)
    private val white = Color.rgb(245, 243, 237)
    private val muted = Color.rgb(174, 174, 180)
    private val createPdfRequest = 701

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        showHome()
    }

    override fun onResume() {
        super.onResume()
        showHome()
    }

    override fun onPause() {
        stopReaderMode()
        super.onPause()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(background)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(28))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        content.addView(text("NFC ELEVATOR ANALYZER", 23f, gold, true, Gravity.CENTER))
        content.addView(text("أداة فحص وتحليل NFC محليًا", 14f, muted, false, Gravity.CENTER), marginParams(top = 7, bottom = 18))

        val statusCard = card()
        statusCard.addView(text("حالة الاتصال", 17f, gold, true))
        statusCard.addView(text(nfcStatus(), 15f, white, false), marginParams(top = 9))
        statusCard.addView(actionButton("تحديث حالة NFC") { refreshNfcStatus(); showHome() }, marginParams(top = 12))
        statusCard.addView(actionButton("فتح إعدادات تشغيل NFC") {
            try {
                startActivity(Intent(Settings.ACTION_NFC_SETTINGS))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
            }
        }, marginParams(top = 8))
        content.addView(statusCard, marginParams(bottom = 14))

        content.addView(NfcGuideView(this), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(205)).apply { bottomMargin = dp(14) })

        val scanCard = card()
        scanCard.addView(text("فحص شريحة NFC", 18f, gold, true))
        scanCard.addView(text("قرّب الشريحة من ظهر الهاتف بعد بدء الفحص. ستظهر فقط البيانات التي يسمح النظام بقراءتها.", 14f, muted), marginParams(top = 8, bottom = 10))
        scanCard.addView(actionButton("ابدأ الفحص") { startReaderMode() })
        scanCard.addView(actionButton("إيقاف الفحص") { stopReaderMode(); toast("تم إيقاف الفحص") }, marginParams(top = 8))
        content.addView(scanCard, marginParams(bottom = 14))

        val toolsCard = card()
        toolsCard.addView(text("الأدوات والبيانات", 18f, gold, true))
        toolsCard.addView(actionButton("آخر نتيجة فحص") { showLastScan() }, marginParams(top = 10))
        toolsCard.addView(actionButton("سجل الفحوصات المحفوظة") { showHistory() }, marginParams(top = 8))
        toolsCard.addView(actionButton("مقارنة آخر فحصين") { compareScans() }, marginParams(top = 8))
        toolsCard.addView(actionButton("تصدير تقرير PDF") { requestPdf() }, marginParams(top = 8))
        toolsCard.addView(actionButton("معلومات وحدود التطبيق") { showAbout() }, marginParams(top = 8))
        content.addView(toolsCard)

        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
        refreshNfcStatus()
    }

    private fun startReaderMode() {
        val adapter = nfcAdapter
        if (adapter == null) {
            toast("هذا الهاتف لا يعلن عن دعم NFC")
            return
        }
        if (!adapter.isEnabled) {
            toast("فعّل NFC من إعدادات النظام أولًا")
            try { startActivity(Intent(Settings.ACTION_NFC_SETTINGS)) } catch (_: Exception) { }
            return
        }
        try {
            val flags = NfcAdapter.FLAG_READER_NFC_A or
                NfcAdapter.FLAG_READER_NFC_B or
                NfcAdapter.FLAG_READER_NFC_F or
                NfcAdapter.FLAG_READER_NFC_V
            adapter.enableReaderMode(this, this, flags, null)
            readerActive = true
            toast("الفحص نشط. قرّب الشريحة من ظهر الهاتف")
        } catch (e: Exception) {
            toast("تعذر بدء الفحص: ${e.localizedMessage ?: "خطأ غير معروف"}")
        }
    }

    private fun stopReaderMode() {
        if (readerActive) {
            try { nfcAdapter?.disableReaderMode(this) } catch (_: Exception) { }
            readerActive = false
        }
    }

    override fun onTagDiscovered(tag: Tag) {
        val techs = tag.techList.map { it.substringAfterLast('.') }.distinct()
        val uid = tag.id.joinToString("") { "%02X".format(it) }.ifBlank { "غير متاح" }
        var ndefInfo = "لا توجد بيانات NDEF قابلة للقراءة أو لم تُكتشف."
        try {
            val ndef = Ndef.get(tag)
            if (ndef != null) {
                ndef.connect()
                val message = ndef.ndefMessage
                ndefInfo = buildString {
                    append("NDEF: موجود\n")
                    append("قابل للكتابة: ${if (ndef.isWritable) "نعم" else "لا"}\n")
                    append("السعة القصوى: ${ndef.maxSize} بايت\n")
                    append("عدد السجلات: ${message?.records?.size ?: 0}")
                    message?.records?.forEachIndexed { index, record ->
                        append("\nالسجل ${index + 1}: النوع ${String(record.type, Charsets.UTF_8).ifBlank { "غير محدد" }}، الحمولة ${record.payload.size} بايت")
                    }
                }
                ndef.close()
            }
        } catch (e: Exception) {
            ndefInfo = "تعذرت قراءة بيانات NDEF: ${e.localizedMessage ?: "غير متاحة"}"
        }

        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        val result = "وقت الفحص: $timestamp\nUID المتاح للنظام: $uid\nالتقنيات: ${techs.joinToString(", ").ifBlank { "غير محددة" }}\n$ndefInfo\n\nتنبيه: UID ليس مفتاح دخول ولا يثبت توافق الشريحة مع أي قارئ."
        runOnUiThread {
            saveScan(result, timestamp, techs.joinToString(", "))
            stopReaderMode()
            showResultDialog(result)
        }
    }

    private fun saveScan(details: String, timestamp: String, technologies: String) {
        val records = try { JSONArray(prefs.getString("history", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val item = JSONObject().apply {
            put("time", timestamp)
            put("technologies", technologies)
            put("details", details)
        }
        val updated = JSONArray().put(item)
        for (i in 0 until minOf(records.length(), 99)) updated.put(records.getJSONObject(i))
        prefs.edit().putString("history", updated.toString()).apply()
    }

    private fun showResultDialog(details: String) {
        AlertDialog.Builder(this)
            .setTitle("نتيجة الفحص")
            .setMessage(details)
            .setPositiveButton("حسنًا", null)
            .setNeutralButton("عرض السجل") { _, _ -> showHistory() }
            .show()
    }

    private fun showLastScan() {
        val history = readHistory()
        val message = if (history.length() == 0) "لا توجد نتائج محفوظة حتى الآن." else history.optJSONObject(0)?.optString("details", "لا توجد بيانات") ?: "لا توجد بيانات"
        AlertDialog.Builder(this).setTitle("آخر نتيجة").setMessage(message).setPositiveButton("إغلاق", null).show()
    }

    private fun showHistory() {
        val history = readHistory()
        if (history.length() == 0) {
            AlertDialog.Builder(this).setTitle("سجل الفحوصات").setMessage("لا توجد فحوصات محفوظة حتى الآن.").setPositiveButton("إغلاق", null).show()
            return
        }
        val labels = Array(history.length()) { i ->
            val item = history.optJSONObject(i)
            "${item?.optString("time", "وقت غير معروف")} — ${item?.optString("technologies", "")}" 
        }
        AlertDialog.Builder(this)
            .setTitle("سجل الفحوصات (${history.length()})")
            .setItems(labels) { _, which ->
                val details = history.optJSONObject(which)?.optString("details", "لا توجد تفاصيل") ?: "لا توجد تفاصيل"
                showResultDialog(details)
            }
            .setPositiveButton("إغلاق", null)
            .setNegativeButton("مسح السجل") { _, _ ->
                AlertDialog.Builder(this).setMessage("هل تريد مسح سجل الفحوصات المحلي؟")
                    .setPositiveButton("مسح") { _, _ -> prefs.edit().remove("history").apply(); toast("تم مسح السجل المحلي") }
                    .setNegativeButton("إلغاء", null).show()
            }.show()
    }

    private fun compareScans() {
        val history = readHistory()
        if (history.length() < 2) {
            toast("تحتاج إلى فحص شريحتين على الأقل للمقارنة")
            return
        }
        val first = history.getJSONObject(0)
        val second = history.getJSONObject(1)
        val comparison = "الفحص الأحدث: ${first.optString("time")}\nالتقنيات: ${first.optString("technologies")}\n\nالفحص السابق: ${second.optString("time")}\nالتقنيات: ${second.optString("technologies")}\n\nهذه مقارنة وصفية للبيانات العامة المتاحة فقط، ولا تحدد صلاحية الدخول أو توافق المصعد."
        AlertDialog.Builder(this).setTitle("مقارنة آخر فحصين").setMessage(comparison).setPositiveButton("إغلاق", null).show()
    }

    private fun requestPdf() {
        val history = readHistory()
        if (history.length() == 0) {
            toast("لا توجد بيانات لتصديرها")
            return
        }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/pdf"
            putExtra(Intent.EXTRA_TITLE, "NFC-Scan-Report.pdf")
        }
        try { startActivityForResult(intent, createPdfRequest) } catch (_: Exception) { toast("تعذر فتح نافذة حفظ PDF") }
    }

    @Deprecated("Deprecated by Android, retained for compatibility with the built-in document picker")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == createPdfRequest && resultCode == RESULT_OK && data?.data != null) {
            try {
                val document = PdfDocument()
                val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
                val page = document.startPage(pageInfo)
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; textSize = 12f }
                val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(150, 105, 25); textSize = 18f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
                var y = 48f
                page.canvas.drawText("NFC ELEVATOR ANALYZER - Scan Report", 36f, y, titlePaint)
                y += 30f
                val history = readHistory()
                for (i in 0 until history.length()) {
                    val item = history.getJSONObject(i)
                    val lines = ("${item.optString("time")} | ${item.optString("technologies")}\n${item.optString("details")}").split("\n")
                    for (line in lines) {
                        if (y > 805f) break
                        val safeLine = line.replace(Regex("[^\\u0000-\\u00FF]"), "?")
                        page.canvas.drawText(safeLine.take(88), 36f, y, paint)
                        y += 17f
                    }
                    y += 10f
                    if (y > 805f) break
                }
                document.finishPage(page)
                contentResolver.openOutputStream(data.data!!)?.use { output -> document.writeTo(output) }
                document.close()
                toast("تم حفظ تقرير PDF")
            } catch (e: Exception) {
                toast("تعذر إنشاء التقرير: ${e.localizedMessage ?: "خطأ"}")
            }
        }
    }

    private fun showAbout() {
        val message = "التطبيق يفحص تقنيات NFC والبيانات العامة التي يسمح Android بقراءتها.\n\nلا ينسخ بطاقات الدخول ولا يستخرج مفاتيح الحماية ولا يتجاوز أنظمة المصاعد. لا يمكن استنتاج توافق قارئ المصعد من UID وحده.\n\nتُحفظ نتائج الفحص محليًا داخل مساحة التطبيق. لا يحتاج الفحص أو السجل إلى اتصال بالإنترنت. حذف التطبيق أو مسح بياناته قد يحذف السجل؛ صدّر تقريرًا عند الحاجة."
        AlertDialog.Builder(this).setTitle("حول التطبيق والخصوصية").setMessage(message).setPositiveButton("إغلاق", null).show()
    }

    private fun readHistory(): JSONArray = try { JSONArray(prefs.getString("history", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }

    private fun nfcStatus(): String = when {
        nfcAdapter == null -> "هذا الهاتف لا يعلن عن وجود NFC."
        nfcAdapter?.isEnabled == true -> "NFC مدعوم ومفعّل حاليًا."
        else -> "NFC متاح لكنه متوقف. فعّله من إعدادات النظام."
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(panel, 18)
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false, gravity: Int = Gravity.START): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        this.gravity = gravity
        if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
        setLineSpacing(dp(3).toFloat(), 1f)
    }

    private fun actionButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 14f
        isAllCaps = false
        setTextColor(Color.rgb(25, 22, 16))
        background = rounded(gold, 12)
        setOnClickListener { action() }
        minHeight = dp(48)
    }

    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun marginParams(top: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        topMargin = dp(top)
        bottomMargin = dp(bottom)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    private class NfcGuideView(activity: Activity) : View(activity) {
        private val goldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(218, 176, 91); style = Paint.Style.STROKE; strokeWidth = 3f }
        private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(29, 29, 35); style = Paint.Style.FILL }
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 15f; textAlign = Paint.Align.CENTER }
        private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(218, 176, 91); style = Paint.Style.STROKE; strokeWidth = 2f }
        private val density = activity.resources.displayMetrics.density
        private var phase = 0f

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            val cx = w / 2f; val top = 16f * density
            val phone = RectF(cx - 54f * density, top, cx + 54f * density, top + 142f * density)
            canvas.drawRoundRect(phone, 17f * density, 17f * density, fillPaint)
            canvas.drawRoundRect(phone, 17f * density, 17f * density, goldPaint)
            canvas.drawCircle(cx, top + 92f * density, (12f + phase * 10f) * density, ringPaint.apply { alpha = 210 - (phase * 130).toInt() })
            canvas.drawCircle(cx, top + 92f * density, (23f + phase * 13f) * density, ringPaint.apply { alpha = 130 - (phase * 90).toInt() })
            canvas.drawText("NFC", cx, top + 98f * density, textPaint)
            val handY = top + (12f + phase * 92f) * density
            textPaint.textSize = 25f * density
            canvas.drawText("☝", cx + 82f * density, handY, textPaint)
            textPaint.textSize = 14f * density
            canvas.drawText("حرّك يدك نحو ظهر الهاتف", cx, h - 18f * density, textPaint)
            phase += 0.035f
            if (phase > 1f) phase = 0f
            postInvalidateDelayed(55)
        }
    }
}
