# NFC ELEVATOR ANALYZER V2

An Android application for inspecting publicly readable NFC tag information.

## Current features
- Detects whether the device has NFC hardware and whether NFC is enabled.
- Reads publicly available tag UID and technology names exposed by Android.
- Attempts to read public NDEF records.
- Stores scan results locally using app-private preferences.
- Shows local scan history and can share/export it as text.
- Arabic/English interface and NFC antenna guidance.
- GitHub Actions workflow builds a debug APK.

## Build
Push the project to the `main` branch. Open **Actions**, wait for **Android APK Build**, then download the `NFC-Elevator-Analyzer-V2-debug` artifact from the successful run.

## Important limitations
- NFC support varies by phone model and region. The app detects actual support at runtime.
- A tag UID does not reveal secret credentials and does not prove compatibility with an elevator reader.
- This app does not clone access cards, extract keys, or bypass access-control systems.
- The current export function shares scan history as text; it is not a PDF backup/restore system.
- Scan history may be lost if app data is cleared or the app is uninstalled. Export it first.
