package com.example.nfcelevator

import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Gold = Color(0xFFD6AD55)
private val Dark = Color(0xFF090A0D)
private val Panel = Color(0xFF17191F)
private val Muted = Color(0xFFB8BBC4)

class MainActivity : ComponentActivity() {
    private var nfcAdapter: NfcAdapter? = null
    private var onTagRead: ((String) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        setContent { AppRoot(nfcAdapter) { callback -> onTagRead = callback } }
    }

    override fun onResume() {
        super.onResume()
        val adapter = nfcAdapter ?: return
        if (adapter.isEnabled) {
            adapter.enableReaderMode(this, { tag ->
                val result = inspectTag(tag)
                runOnUiThread { onTagRead?.invoke(result) }
            }, NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B or
                    NfcAdapter.FLAG_READER_NFC_F or NfcAdapter.FLAG_READER_NFC_V or
                    NfcAdapter.FLAG_READER_NO_PLATFORM_SOUNDS, null)
        }
    }

    override fun onPause() {
        nfcAdapter?.disableReaderMode(this)
        super.onPause()
    }

    private fun inspectTag(tag: Tag): String {
        val uid = tag.id.joinToString("") { "%02X".format(it) }
        val tech = tag.techList.map { it.substringAfterLast('.') }.distinct().joinToString(", ")
        val ndefText = try {
            val ndef = Ndef.get(tag)
            if (ndef != null) {
                ndef.connect()
                val records = ndef.ndefMessage?.records?.mapNotNull { record ->
                    runCatching { String(record.payload, Charsets.UTF_8).trim('\u0000', '\u0002') }.getOrNull()
                }.orEmpty()
                ndef.close()
                records.filter { it.isNotBlank() }.joinToString(" | ")
            } else "No NDEF data"
        } catch (_: Exception) { "NDEF unavailable or unreadable" }
        return "UID: $uid\nTechnologies: $tech\nNDEF: $ndefText\nTime: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())}"
    }
}

@Composable
private fun AppRoot(adapter: NfcAdapter?, registerReader: (((String) -> Unit) -> Unit)) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("nfc_analyzer", android.content.Context.MODE_PRIVATE) }
    var page by remember { mutableStateOf("home") }
    var scanResult by remember { mutableStateOf("لم يتم اكتشاف بطاقة بعد") }
    var history by remember { mutableStateOf(prefs.getString("history", "").orEmpty().split("\n---\n").filter { it.isNotBlank() }) }
    var english by remember { mutableStateOf(prefs.getBoolean("english", false)) }
    val isEnabled = adapter?.isEnabled == true
    val hasNfc = adapter != null

    SideEffect {
        registerReader { result ->
            scanResult = result
            history = listOf(result) + history
            prefs.edit().putString("history", history.joinToString("\n---\n")).apply()
        }
    }
    BackHandler(page != "home") { page = "home" }

    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Dark, surface = Panel)) {
        Column(Modifier.fillMaxSize().background(Dark).padding(18.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("NFC ANALYZER", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("V2.0", color = Muted, fontSize = 12.sp)
            }
            Spacer(Modifier.height(18.dp))
            when (page) {
                "home" -> HomePage(hasNfc, isEnabled, english, onNavigate = { page = it }, onSettings = {
                    runCatching { context.startActivity(android.content.Intent(android.provider.Settings.ACTION_NFC_SETTINGS)) }
                })
                "scan" -> ScanPage(scanResult, hasNfc, isEnabled, english)
                "guide" -> GuidePage(english)
                "history" -> HistoryPage(history, english, onClear = {
                    history = emptyList(); prefs.edit().remove("history").apply()
                })
                "settings" -> SettingsPage(english, onLanguage = {
                    english = it; prefs.edit().putBoolean("english", it).apply()
                }, onExport = {
                    val text = history.joinToString("\n\n----------------\n\n")
                    val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                        type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, text)
                    }
                    context.startActivity(android.content.Intent.createChooser(send, "Export scan history"))
                })
            }
            Spacer(Modifier.weight(1f))
            if (page != "home") GoldButton(if (english) "HOME" else "الرئيسية") { page = "home" }
            Text("For public NFC inspection only • No access-card cloning", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 10.dp))
        }
    }
}

@Composable
private fun HomePage(hasNfc: Boolean, enabled: Boolean, english: Boolean, onNavigate: (String) -> Unit, onSettings: () -> Unit) {
    Text(if (english) "DEVICE STATUS" else "حالة الجهاز", color = Muted, fontSize = 13.sp)
    Spacer(Modifier.height(8.dp))
    CardBox {
        Text(if (english) "NFC hardware" else "وجود NFC", color = Muted)
        Text(if (hasNfc) if (english) "Available" else "متوفر" else if (english) "Not supported" else "غير مدعوم", color = if (hasNfc) Gold else Color.Red, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(if (english) "NFC status" else "حالة التشغيل", color = Muted)
        Text(if (enabled) if (english) "Enabled" else "مُفعّل" else if (hasNfc) if (english) "Disabled" else "متوقف" else "—", color = if (enabled) Gold else Muted, fontSize = 18.sp)
        if (hasNfc && !enabled) { Spacer(Modifier.height(8.dp)); GoldButton(if (english) "OPEN NFC SETTINGS" else "فتح إعدادات NFC", onSettings) }
    }
    Spacer(Modifier.height(14.dp))
    GoldButton(if (english) "START NFC SCAN" else "بدء فحص NFC") { onNavigate("scan") }
    Spacer(Modifier.height(9.dp))
    GoldButton(if (english) "HOW TO FIND NFC SENSOR" else "مكان حساس NFC") { onNavigate("guide") }
    Spacer(Modifier.height(9.dp))
    GoldButton(if (english) "SCAN HISTORY" else "سجل الفحوصات") { onNavigate("history") }
    Spacer(Modifier.height(9.dp))
    GoldButton(if (english) "SETTINGS & EXPORT" else "الإعدادات والتصدير") { onNavigate("settings") }
}

@Composable
private fun ScanPage(result: String, hasNfc: Boolean, enabled: Boolean, english: Boolean) {
    Text(if (english) "NFC SCANNER" else "فاحص NFC", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(12.dp))
    CardBox {
        Text(if (english) "Bring a supported NFC tag close to the phone's NFC antenna." else "قرّب بطاقة أو وسم NFC مدعومًا من ظهر الهاتف.", color = Color.White)
        Spacer(Modifier.height(10.dp))
        Text(if (!hasNfc) "NFC غير مدعوم على هذا الهاتف" else if (!enabled) "فعّل NFC من إعدادات النظام أولًا" else "في انتظار اكتشاف وسم NFC…", color = Gold)
    }
    Spacer(Modifier.height(12.dp))
    Text(if (english) "LATEST RESULT" else "آخر نتيجة", color = Muted)
    CardBox { Text(result, color = Color.White, fontSize = 13.sp) }
    Spacer(Modifier.height(10.dp))
    Text(if (english) "A UID alone does not identify an access credential or prove compatibility with an elevator reader." else "رقم UID وحده لا يكشف بيانات الدخول ولا يثبت التوافق مع قارئ المصعد.", color = Muted, fontSize = 12.sp)
}

@Composable
private fun GuidePage(english: Boolean) {
    Text(if (english) "FIND THE NFC ANTENNA" else "تحديد مكان حساس NFC", color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(12.dp))
    CardBox {
        Text("▱", color = Gold, fontSize = 72.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        Text(if (english) "The NFC antenna is commonly located around the upper or middle back of a phone, but its exact position varies by model." else "غالبًا يكون حساس NFC قرب الجزء العلوي أو الأوسط من ظهر الهاتف، لكن مكانه الدقيق يختلف حسب موديل الهاتف.", color = Color.White)
        Spacer(Modifier.height(8.dp))
        Text(if (english) "Move the tag slowly across the back of the phone. Check the manufacturer's specifications for the exact antenna position." else "حرّك الوسم ببطء على ظهر الهاتف. راجع مواصفات الشركة لمعرفة المكان الدقيق لهاتفك.", color = Muted)
    }
}

@Composable
private fun HistoryPage(history: List<String>, english: Boolean, onClear: () -> Unit) {
    Text(if (english) "LOCAL HISTORY" else "السجل المحلي", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(10.dp))
    if (history.isEmpty()) Text(if (english) "No scans saved yet." else "لا توجد فحوصات محفوظة.", color = Muted)
    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(history) { item -> CardBox { Text(item, color = Color.White, fontSize = 12.sp) } }
    }
    if (history.isNotEmpty()) { Spacer(Modifier.height(8.dp)); GoldButton(if (english) "CLEAR HISTORY" else "مسح السجل", onClear) }
}

@Composable
private fun SettingsPage(english: Boolean, onLanguage: (Boolean) -> Unit, onExport: () -> Unit) {
    Text(if (english) "SETTINGS" else "الإعدادات", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(12.dp))
    CardBox {
        Text(if (english) "Language" else "اللغة", color = Color.White)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("العربية", color = Gold, modifier = Modifier.weight(1f))
            Switch(checked = english, onCheckedChange = onLanguage)
            Text("English", color = Gold)
        }
    }
    Spacer(Modifier.height(10.dp))
    GoldButton(if (english) "SHARE / EXPORT HISTORY" else "مشاركة / تصدير السجل", onExport)
    Spacer(Modifier.height(12.dp))
    Text(if (english) "Data is stored locally. Export a copy before clearing app data or uninstalling." else "تُحفظ البيانات محليًا. صدّر نسخة قبل مسح بيانات التطبيق أو حذفه.", color = Muted, fontSize = 12.sp)
}

@Composable
private fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
private fun GoldButton(label: String, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Dark), shape = RoundedCornerShape(14.dp)) {
        Text(label, fontWeight = FontWeight.Bold)
    }
}
