package com.example.nfcelevator

import android.app.Activity
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), NfcAdapter.ReaderCallback {
    private var adapter: NfcAdapter? = null
    private lateinit var status: TextView
    private lateinit var results: TextView
    private lateinit var header: TextView
    private lateinit var root: LinearLayout

    private val bg = Color.rgb(12, 14, 19)
    private val panel = Color.rgb(24, 28, 36)
    private val gold = Color.rgb(220, 180, 92)
    private val muted = Color.rgb(170, 177, 190)
    private val white = Color.WHITE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        adapter = NfcAdapter.getDefaultAdapter(this)
        buildUi()
        when {
            adapter == null -> showStatus("هذا الهاتف لا يحتوي على NFC", false)
            !adapter!!.isEnabled -> showStatus("فعّل NFC من إعدادات الهاتف ثم ارجع للتطبيق", false)
            else -> showStatus("جاهز للفحص — قرّب الشريحة من ظهر الهاتف", true)
        }
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
            setBackgroundColor(bg)
        }
        header = TextView(this).apply {
            text = "NFC ELEVATOR\nANALYZER"
            textSize = 25f
            setTextColor(gold)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        root.addView(header, LinearLayout.LayoutParams(-1, dp(88)))
        val subtitle = TextView(this).apply {
            text = "أداة تشخيص وقراءة معلومات NFC المتاحة"
            textSize = 14f
            setTextColor(muted)
            gravity = Gravity.CENTER
        }
        root.addView(subtitle, LinearLayout.LayoutParams(-1, dp(42)))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(panel)
        }
        status = TextView(this).apply {
            textSize = 17f
            setTextColor(white)
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        card.addView(status, LinearLayout.LayoutParams(-1, dp(62)))
        val hint = TextView(this).apply {
            text = "اترك التطبيق مفتوحًا ثم قرّب الشريحة من ظهر الهاتف. سيبدأ الفحص تلقائيًا عند اكتشافها."
            textSize = 13f
            setTextColor(muted)
            gravity = Gravity.CENTER
        }
        card.addView(hint, LinearLayout.LayoutParams(-1, dp(66)))
        root.addView(card, LinearLayout.LayoutParams(-1, -2))

        val resultTitle = TextView(this).apply {
            text = "نتيجة آخر فحص"
            textSize = 18f
            setTextColor(gold)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(22), 0, dp(10))
        }
        root.addView(resultTitle)
        results = TextView(this).apply {
            text = "لم يتم اكتشاف شريحة بعد."
            textSize = 14f
            setTextColor(white)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(panel)
            setTextIsSelectable(true)
        }
        val scroll = ScrollView(this)
        scroll.addView(results)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val note = TextView(this).apply {
            text = "ملاحظة: الهاتف يفحص تقنيات NFC بتردد 13.56 MHz فقط تقريبًا؛ لا يستطيع قراءة بطاقات 125 kHz أو استخراج مفاتيح الحماية أو نسخ اعتماد دخول."
            textSize = 12f
            setTextColor(muted)
            setPadding(0, dp(14), 0, 0)
        }
        root.addView(note)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        val a = adapter ?: return
        if (!a.isEnabled) {
            showStatus("فعّل NFC من إعدادات الهاتف", false)
            return
        }
        try {
            a.enableReaderMode(
                this,
                this,
                NfcAdapter.FLAG_READER_NFC_A or
                    NfcAdapter.FLAG_READER_NFC_B or
                    NfcAdapter.FLAG_READER_NFC_F or
                    NfcAdapter.FLAG_READER_NFC_V or
                    NfcAdapter.FLAG_READER_NO_PLATFORM_SOUNDS,
                null
            )
            showStatus("جاهز للفحص — قرّب الشريحة من ظهر الهاتف", true)
        } catch (e: Exception) {
            showStatus("تعذر تشغيل وضع القراءة: ${e.message ?: "خطأ غير معروف"}", false)
        }
    }

    override fun onPause() {
        try { adapter?.disableReaderMode(this) } catch (_: Exception) {}
        super.onPause()
    }

    override fun onTagDiscovered(tag: Tag) {
        val techs = tag.techList.map { it.substringAfterLast('.') }.distinct()
        val lines = mutableListOf<String>()
        lines += "الحالة: تم اكتشاف شريحة NFC"
        lines += "وقت الفحص: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())}"
        lines += ""
        lines += "تقنيات تعرف عليها الهاتف:"
        if (techs.isEmpty()) lines += "• لم يعلن الجهاز عن تقنيات قابلة للقراءة"
        else techs.forEach { lines += "• $it" }

        val standards = mutableListOf<String>()
        if (techs.any { it == "NfcA" }) standards += "NFC-A / ISO 14443 Type A"
        if (techs.any { it == "NfcB" }) standards += "NFC-B / ISO 14443 Type B"
        if (techs.any { it == "NfcF" }) standards += "NFC-F / FeliCa"
        if (techs.any { it == "NfcV" }) standards += "NFC-V / ISO 15693"
        lines += ""
        lines += "المعايير المحتملة:"
        lines += if (standards.isEmpty()) "• غير محددة من واجهة الهاتف" else standards.joinToString("\n") { "• $it" }

        lines += ""
        lines += "فحص NDEF:"
        val ndef = Ndef.get(tag)
        if (ndef == null) {
            lines += "• لم يتم اكتشاف واجهة NDEF"
        } else {
            try {
                ndef.connect()
                lines += "• نوع البطاقة: ${ndef.type ?: "غير معلن"}"
                lines += "• السعة القصوى: ${ndef.maxSize} بايت"
                lines += "• قابلة للكتابة: ${if (ndef.isWritable) "نعم" else "لا"}"
                lines += "• رسالة NDEF موجودة: ${if (ndef.cachedNdefMessage != null) "نعم" else "لا"}"
            } catch (e: Exception) {
                lines += "• تعذر قراءة خصائص NDEF: ${e.message ?: "غير متاح"}"
            } finally {
                try { ndef.close() } catch (_: Exception) {}
            }
        }

        lines += ""
        lines += "حدود الفحص:"
        lines += "• لا يمكن استنتاج اسم الشركة أو التردد الدقيق دائمًا من بيانات الهاتف."
        lines += "• لا يتم عرض UID أو مفاتيح سرية أو بيانات اعتماد قابلة لإعادة الاستخدام."
        lines += "• إذا كانت الشريحة 125 kHz فلن يستطيع NFC في الهاتف اكتشافها."
        lines += "• ظهور نوع تقنية لا يعني أن الهاتف يستطيع محاكاة البطاقة أو فتح الأسانسير."

        val output = lines.joinToString("\n")
        runOnUiThread {
            showStatus("تم الفحص بنجاح", true)
            results.text = output
        }
    }

    private fun showStatus(message: String, good: Boolean) {
        if (::status.isInitialized) {
            status.text = message
            status.setTextColor(if (good) gold else Color.rgb(255, 150, 130))
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
