NFC ELEVATOR ANALYZER - مشروع Android

المحتويات:
- تطبيق Kotlin بسيط يفعّل NFC Reader Mode أثناء فتح التطبيق.
- يكتشف تقنيات NFC التي يعلنها Android.
- يفحص خصائص NDEF العامة عند توفرها.
- لا يعرض UID ولا يستخرج مفاتيح حماية ولا ينسخ بطاقات دخول.

مهم:
- Android NFC يعمل مع تقنيات 13.56 MHz المتوافقة، ولا يقرأ بطاقات 125 kHz.
- لا يمكن استنتاج اسم الشركة أو التردد الدقيق دائمًا من الهاتف وحده.
- هذا المشروع ليس أداة لفتح المصعد أو محاكاة بطاقة دخول.

لبناء APK:
1) افتح مجلد المشروع في Android Studio حديث.
2) انتظر Gradle Sync.
3) اختر Build > Build APK(s).
4) ستجد الملف عادة في app/build/outputs/apk/debug/app-debug.apk

المتطلبات: Android Studio، JDK 17، Android SDK 35، واتصال إنترنت أول مرة لتنزيل Gradle ومكونات Android.
